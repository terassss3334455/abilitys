AbilitysgorwMOD 1.6.3 - 解析用バンドル

重要:
- 元のJARに .java のオリジナルソースコードは含まれていません。
- このZIPには、コンパイル済み .class 全657個、必要なMETA-INF/設定、
  内包Agent JAR、および重要クラスの javap バイトコード表示を収録しています。
- javap表示はJavaソースへの完全な逆コンパイルではありません。
  コメント・一部の変数名・ソース構造は失われています。
- 正確なソースレビューには、IntelliJプロジェクトの src/main/java、
  src/main/resources、build.gradle、gradle.properties 等を別途ZIP化してください。

優先確認対象:
1. AjceAgentBootstrap / AjceCurseForgeAutoSetup / AjceProtectionEngine
2. PrelaunchBootstrapInstaller
3. AbsoluteSovereign* 系
4. CrossModProtection / CrossModUniversalAttack 系
5. abilitysgorwmod.mixins.json / META-INF/mods.toml / MANIFEST.MF

フォルダ:
- extracted/ : 抽出した全 .class と必要なMETA-INF設定
- javap_readable/ : 重要クラスのバイトコード表示
